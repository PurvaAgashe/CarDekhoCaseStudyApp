package com.jspides.carddekho_case_study.entity;

public class car {

	private int car_id;
	private String name;
	private String model;
	private String brand;
	private String fuel_type;
	private double price;
	
	public String toString() {
		return "car_id  " + car_id + 
				"   model  "+ model 
				+"    name  "+ name
				+"    brand  "+brand
				+"   fuel_type  "+fuel_type
				+"    price  "+price;
	}
	   

	public int get_car_id() {
	   return this.car_id;
	}
	public String get_name() {
		return this.name;	
	}
	public String get_model() {
		return this.model;
	}
	public String get_brand() {
		return this.brand;
	}
	public String get_fuel_type() {
		return this.fuel_type;
	}
	public double get_price() {
		return this.price;
	}
	public void set_car_id(int id) {
		this.car_id=id;
	}
	public void set_name(String name) {
		this.name=name;
	}
	public void set_mode(String model ) {
		this.model=model;
	}
	public void set_brand(String brand ) {
		this.brand=brand;
	}
	public void set_fuel_type(String fuel_type ) {
		this.fuel_type=fuel_type;
	}
    public void set_price(double price ) {
	this.price=price;
}

}
