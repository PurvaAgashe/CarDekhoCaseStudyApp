package com.jspides.carddekho_case_study.operation;

import java.util.Scanner;

import com.jspides.carddekho_case_study.entity.car;
import com.jspides.carddekho_case_study.main.car_dekho_menu;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

public class car_operation { 
	private static Connection connection;
	private static PreparedStatement preparedStatement;
	private static int Result;
	private static ResultSet resultSet;
	private static Properties properties=new Properties();
	private static FileInputStream file;
	private static String filepath="C:\\Users\\pagas\\weje2\\carddekho_case_study - Copy\\src\\Resources\\db_info.Properties ";
	private static String query;
	private static void OpenConnection() { 
		try {
			file=new FileInputStream(filepath);
			properties.load(file);
			Class.forName(properties.getProperty("driverpath"));
			connection=DriverManager.getConnection(properties.getProperty("dburl"),properties);
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		}
		private static void closeConnection() {
			try {
				if (connection !=null) {
					connection.close();
					
				}if (preparedStatement !=null) {
					preparedStatement.close();
					
				}
				if (resultSet !=null) {
					resultSet.close();
				}
				if (file !=null) {
					file.close();	
				}
				if (Result !=0) {
					Result=0;
					
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				
			}
			
		}
	
	car_dekho_menu car_dekho_menu=new car_dekho_menu();
	 List <car> cars=new ArrayList<car>();
	 car car1=new car();
	public void add_operation() {
		try {
			OpenConnection();
			
			Scanner obj2 = new Scanner(System.in) ;
			System.out.println("enter car id");
			int id=obj2.nextInt();
			System.out.println("enter car name");
			String name=obj2.next();
			System.out.println("enter car model name");
			String model=obj2.next();
			System.out.println("enter car brand");
			String brand=obj2.next() ;
			System.out.println("enter car fuel type");
			String fuel=obj2.next();
			System.out.println("enter car price");
			Double price=obj2.nextDouble();
			query="insert into car_details (id,name,model,brand,fuel,price) values(?,?,?,?,?,?)"; 
			 preparedStatement=connection.prepareStatement(query);
			 preparedStatement.setInt(1, id);
			 preparedStatement.setString(2, name);
			 preparedStatement.setString(3, model);
			 preparedStatement.setString(4, brand);
			 preparedStatement.setString(5, fuel);
			 preparedStatement.setDouble(6, price);
			
			 Result=preparedStatement.executeUpdate();
			 System.out.println("query of "+ Result+"row(s) affected");
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally {
			closeConnection();
		}
			 
          }	 
	public void getAllDetails() {  
		try {
			OpenConnection();
			
	        query = "SELECT * FROM car_details ";
	        preparedStatement = connection.prepareStatement(query);
	        resultSet = preparedStatement.executeQuery();

	        while (resultSet.next()) {
	        	System.out.println(resultSet.getInt("id")+"|"+resultSet.getString("name")+"|"+resultSet.getString("model")+"|"+resultSet.getString("brand")+"|"+resultSet.getString("fuel")+"|"+resultSet.getDouble("price"));
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection();
		}         
	}   
	
	public void searchByName() {
		try {
			OpenConnection();
			Scanner scanner=new Scanner(System.in);
			System.out.println("enter the name");
			String searchName=scanner.next();
	        query = "SELECT * FROM car_details WHERE NAME=?";
	        preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setString(1,searchName );

	        resultSet = preparedStatement.executeQuery();
	        boolean found=false;

	        while (resultSet.next()) {
	        	found=true;
	        	System.out.println(resultSet.getInt("id")+"|"+resultSet.getString("name")+"|"+resultSet.getString("model")+"|"+resultSet.getString("brand")+"|"+resultSet.getString("fuel")+"|"+resultSet.getDouble("price"));
	        }
	        if (found==false) {
				System.out.println("no result found");
			}
	        
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection();
		}
	}
	public void searchByBrand(){
		try {
			OpenConnection();
			Scanner scanner=new Scanner(System.in);
			System.out.println("enter the Brand");
			String searchBrand=scanner.next();
	        query = "SELECT * FROM car_details WHERE BRAND=?";
	        preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setString(1,searchBrand );

	        resultSet = preparedStatement.executeQuery();
	        boolean found=false;

	        while (resultSet.next()) {
	        	found=true;
	        	System.out.println(resultSet.getInt("id")+"|"+resultSet.getString("name")+"|"+resultSet.getString("model")+"|"+resultSet.getString("brand")+"|"+resultSet.getString("fuel")+"|"+resultSet.getDouble("price"));
	        }
	        if (found==false) {
				System.out.println("no result found");
			}
	        
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection();
		}
	}
	public void searchByFuel_type() {
		try {
			OpenConnection();
			Scanner scanner=new Scanner(System.in);
			System.out.println("enter the fuel");
			String searchfuel=scanner.next();
	        query = "SELECT * FROM car_details WHERE fuel=?";
	        preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setString(1,searchfuel );

	        resultSet = preparedStatement.executeQuery();
	        boolean found=false;

	        while (resultSet.next()) {
	        	found=true;
	        	System.out.println(resultSet.getInt("id")+"|"+resultSet.getString("name")+"|"+resultSet.getString("model")+"|"+resultSet.getString("brand")+"|"+resultSet.getString("fuel")+"|"+resultSet.getDouble("price"));
	        }
	        if (found==false) {
				System.out.println("no result found");
			}
	        
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection();
		}
	}
	public void updateCarDetails() {
		try {
			OpenConnection();
			try {
				OpenConnection();
				
		        query = "SELECT * FROM car_details ";
		        preparedStatement = connection.prepareStatement(query);
		        resultSet = preparedStatement.executeQuery();

		        while (resultSet.next()) {
		        	System.out.println(resultSet.getInt("id")+"|"+resultSet.getString("name")+"|"+resultSet.getString("model")+"|"+resultSet.getString("brand")+"|"+resultSet.getString("fuel")+"|"+resultSet.getDouble("price"));
		        }
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("update details");
			Scanner scanner = new Scanner(System.in) ;
			System.out.println("enter the id ");
			int cartoUpdate=scanner.nextInt();
			
			 System.out.println("Enter new details for the car:");
		        System.out.print("Name: ");
		        String name = scanner.next();
		        System.out.print("model: ");
		        String model = scanner.next();
		        System.out.print("brand: ");
		        String brand = scanner.next();
		        System.out.print("fuel: ");
		        String fuel = scanner.next();
		        System.out.print("price: ");
		        double price = scanner.nextDouble();
			query="update car_details set name=?, model=?, brand=?, fuel=?, price=? where id=?";
			preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1, name);
			preparedStatement.setString(2, model);
			preparedStatement.setString(3, brand);
			preparedStatement.setString(4, fuel);
			preparedStatement.setDouble(5, price);
			preparedStatement.setInt(6, cartoUpdate);
			int rowsUpdated = preparedStatement.executeUpdate();

			 Result=preparedStatement.executeUpdate();
			 System.out.println("query of "+ Result+"row(s) affected");
				
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection();
		}
		
		}
	public void deleteCarDetails() {
		try {
			OpenConnection();
			try {
				OpenConnection();
				
		        query = "SELECT * FROM car_details ";
		        preparedStatement = connection.prepareStatement(query);
		        resultSet = preparedStatement.executeQuery();

		        while (resultSet.next()) {
		        	System.out.println(resultSet.getInt("id")+"|"+resultSet.getString("name")+"|"+resultSet.getString("model")+"|"+resultSet.getString("brand")+"|"+resultSet.getString("fuel")+"|"+resultSet.getDouble("price"));
		        }
			} catch (Exception e) {
				e.printStackTrace();
			}
			Scanner scanner= new Scanner(System.in) ;
			System.out.println("enter the serial no");
			query="delete from car_details where id=?";
			preparedStatement=connection.prepareStatement(query);
					preparedStatement.setInt(1, scanner.nextInt());
					
					Result=preparedStatement.executeUpdate();
					System.out.println("query ok"+Result+"no of row(s) affected");
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection();
		}
		
	
		
	}
		
	} 	
	
		
	

